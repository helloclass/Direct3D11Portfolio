#include "Util.h"
#include <filesystem>

GlobalTime GlobalTime::gt;
GlobalKeyVector GlobalKeyVector::kv;

#pragma region UI_HWND

void UI_HWND::setVisible(bool isVisible)
{
	if (!isVisible)
		ShowWindow(hwnd, SW_HIDE);
	else
		ShowWindow(hwnd, SW_SHOW);
}

#pragma endregion

std::string Path2FileName(const char* texIter)
{
	std::string TexName;

	UINT texOffset = 0;
	UINT texSize = strlen(texIter);

	for (int t = texSize - 1; t >= 0; t--)
	{
		if ((texIter)[t] == '/' or (texIter)[t] == '\\')
		{
			texOffset = t + 1;
			break;
		}
	}

	for (int t = texOffset; t < texSize; t++)
		TexName += (texIter)[t];

	return TexName;
}

void CreateFolders(std::string path)
{
	std::filesystem::path p(path);
	if (!std::filesystem::is_directory(p))
		std::filesystem::create_directories(p);
}

// ��Ʈ ���� ��� ���� �н��� ����
void GetAllSubFolders(std::string root, std::vector<std::string>& Folders)
{
	for (const auto& file : directory_iterator(root))
	{
		Folders.push_back(file.path().string());
	}
}

/**
*
* �ִϸ��̼ǿ� ��Ÿ ������ ������ ���� �������� ����ȴ�.
* �� B0, B1, B2 �� ���� �� B0�� ��Ÿ�� ����ȴ�. �̶� �WŸ�� ����� B2��?
*
* B2_ = Vn * B2 * (B0)^-1 * B0_delta * B0
*
* �̶� ����� ���� "���չ�Ģ"�� �����ȴ�.
*
* B2_ = Vn * B2 * ((B0)^-1 * B0_delta * B0)
*
* Q> ��Ÿ�� ���ؾ� �ϴ� ������?
*
*/

// ���� ��Ÿ�� ������Ʈ �Ѵ�.
// 
// ����� �״��� ���� ����.
// ��ĳ����� ���� ���չ�Ģ�� �����ǹǷ� ��� ���ؽ��� ���ؼ� ���ο� ������ �� �ʿ䰡 ����.
// ���� ȸ�� => ���� ����
//
void ObjectData::UpdateBoneDelta()
{
	Tree<Skeleton>* Node = nullptr;
	std::queue<Tree<Skeleton>*> skeletons;
	skeletons.push(&BoneHierarchy);

	int qSize = 0;

	while (skeletons.size())
	{
		qSize = skeletons.size();

		// ���� ������ ���̷��� ���� ��ŭ
		while (qSize--)
		{
			Node = skeletons.front();
			skeletons.pop();

			Node->Item.DeltaWeightMatrix = {
				1.0f, 0.0f, 0.0f, 0.0f,
				0.0f, 1.0f, 0.0f, 0.0f,
				0.0f, 0.0f, 1.0f, 0.0f,
				0.0f, 0.0f, 0.0f, 1.0f
			};

			// ��Ÿ ����ġ ��Ʈ���� ����
			if (Node->Parent)
			{
				Node->Item.DeltaWeightMatrix =
					// ((Bone_Mat)^-1 * Bone_Delta * Bone_Mat)
					inverse(Node->Item.TranslationMatrix) *
					Node->Item.DeltaTranslationMatrix *
					Node->Item.TranslationMatrix *

					// Previous_Bone_Weight_Matrix
					// �ڼ� ����� �θ� ���뿡 ���ӵǾ� ����
					Node->Parent->Item.DeltaWeightMatrix; 
			}

			// ���� ���ϵ� �ҷ�����
			for (Tree<Skeleton>* child : Node->Childs)
				skeletons.push(child);
		}
	}
}

// ���� ������ �Ȱ����� true ���� �ٸ��� false
bool ObjectData::CheckSibilingSkeletal(ObjectData* target)
{
	Tree<Skeleton>* Node = nullptr;
	Tree<Skeleton>* TargetNode = nullptr;

	std::queue<Tree<Skeleton>*> skeletons;
	std::queue<Tree<Skeleton>*> TargetSkeletons;

	skeletons.push(&BoneHierarchy);
	TargetSkeletons.push(&target->BoneHierarchy);

	int qSize = 0;

	while (skeletons.size())
	{
		qSize = skeletons.size();

		// ���� ������ ���̷��� ���� ��ŭ
		while (qSize--)
		{
			Node = skeletons.front();
			skeletons.pop();

			TargetNode = TargetSkeletons.front();
			TargetSkeletons.pop();

			// ���� ������ �ٸ��ٸ�
			if (Node->Childs.size() != TargetNode->Childs.size())
				return false;

			// ���� ���ϵ� �ҷ�����
			for (Tree<Skeleton>* child : Node->Childs)
				skeletons.push(child);
			for (Tree<Skeleton>* child : TargetNode->Childs)
				TargetSkeletons.push(child);
		}
	}

	return true;
}

bool ObjectData::CheckSibilingMesh(ObjectData* target)
{
	// �켱 ����޽� ���� ���� ������ Ȯ��
	if (SubmeshCount != target->SubmeshCount)
		return false;

	// ����޽��� ���ٸ� 
	// ����޽� ��ŭ ������ ������, ���ؽ��� �ε����� �����Ѵ�.
	int VertexCompare1, VertexCompare2;
	int IndexCompare1, IndexCompare2;

	for (int submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
	{
		VertexCompare1 = meshDatas[submeshIDX].Vertices.size();
		VertexCompare2 = target->meshDatas[submeshIDX].Vertices.size();

		if (VertexCompare1 != VertexCompare2)
			return false;

		IndexCompare1 = meshDatas[submeshIDX].Indices32.size();
		IndexCompare2 = target->meshDatas[submeshIDX].Indices32.size();

		if (IndexCompare1 != IndexCompare2)
			return false;
	}

	return true;
}

bool ObjectData::ImportAnimationSequence(std::string Path)
{
	std::ifstream SequenceFile(Path, std::ifstream::binary);
	if (!SequenceFile) {
		MessageBoxA(0, "Sequence File Not Found", "Warning", MB_OK);
		return false;
	}

	UINT SequenceFrameString;
	SequenceFile >> SequenceFrameString;

	Sequence* newAnimation = CreateSequence();
	newAnimation->mName = Path2FileName(Path.c_str());

	newAnimation->mSubmeshSize = SubmeshCount;
	newAnimation->mFrameSize = SequenceFrameString;
	newAnimation->mClusterSize = BoneCount;

	newAnimation->mAnimVertexArrays = new float*** [SubmeshCount];
	for (int submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
	{
		newAnimation->mAnimVertexArrays[submeshIDX] = new float** [SequenceFrameString];
		for (int FrameIDX = 0; FrameIDX < SequenceFrameString; FrameIDX++)
		{
			newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX] = new float* [BoneCount];
			for (int ClusterIDX = 0; ClusterIDX < BoneCount; ClusterIDX++)
			{
				newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX] = new float[16];
				for (int i = 0; i < 16; i++)
				{
					SequenceFile.read(
						reinterpret_cast<char*>(&newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX][i]),
						sizeof(float)
					);
				}
			}
		}
	}

	newAnimation->mFrameLength = SequenceFrameString;



	SequenceFile.close();
	
	return true;
}

bool ObjectData::ImportAnimationMontage(std::string Path)
{
	std::ifstream SequenceFile(Path, std::ifstream::binary);
	if (!SequenceFile) {
		MessageBoxA(0, "Sequence File Not Found", "Warning", MB_OK);
		return false;
	}

	UINT SequenceFrameString;
	SequenceFile >> SequenceFrameString;

	Sequence* newAnimation = CreateSequence();
	newAnimation->mName = Path2FileName(Path.c_str());

	newAnimation->mAnimVertexArrays = new float*** [SubmeshCount];
	for (int submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
	{
		newAnimation->mAnimVertexArrays[submeshIDX] = new float** [SequenceFrameString];
		for (int FrameIDX = 0; FrameIDX < SequenceFrameString; FrameIDX++)
		{
			newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX] = new float* [BoneCount];
			for (int ClusterIDX = 0; ClusterIDX < BoneCount; ClusterIDX++)
			{
				newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX] = new float[16];
				for (int i = 0; i < 16; i++)
				{
					SequenceFile.read(
						reinterpret_cast<char*>(&newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX][i]),
						sizeof(float)
					);
				}
			}
		}
	}

	newAnimation->mFrameLength = SequenceFrameString;

	SequenceFile.close();

	return true;
}

bool ObjectData::ImportAnimationMorph(std::string Path)
{
	std::ifstream SequenceFile(Path, std::ifstream::binary);
	if (!SequenceFile) {
		MessageBoxA(0, "Sequence File Not Found", "Warning", MB_OK);
		return false;
	}

	UINT SequenceFrameString;
	SequenceFile >> SequenceFrameString;

	Sequence* newAnimation = CreateSequence();
	newAnimation->mName = Path2FileName(Path.c_str());

	newAnimation->mAnimVertexArrays = new float*** [SubmeshCount];
	for (int submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
	{
		newAnimation->mAnimVertexArrays[submeshIDX] = new float** [SequenceFrameString];
		for (int FrameIDX = 0; FrameIDX < SequenceFrameString; FrameIDX++)
		{
			newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX] = new float* [BoneCount];
			for (int ClusterIDX = 0; ClusterIDX < BoneCount; ClusterIDX++)
			{
				newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX] = new float[16];
				for (int i = 0; i < 16; i++)
				{
					SequenceFile.read(
						reinterpret_cast<char*>(&newAnimation->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX][i]),
						sizeof(float)
					);
				}
			}
		}
	}

	newAnimation->mFrameLength = SequenceFrameString;

	SequenceFile.close();

	return true;
}

bool ObjectData::ExportAnimationSequence(ObjectData* target, std::string name)
{
	if (!CheckSibilingSkeletal(target))
		return false;

	std::string DirPath = 
		"MetaData\\" + this->objectName + "\\Sequence";
	std::string Path;

	if (name.empty())
	{
		Path = DirPath + "\\" + target->objectName + ".seq";
	}
	else
	{
		Path = DirPath + "\\" + name + ".seq";
	}

	// ���� ����
	CreateFolders(DirPath);

	// ���� ���� �� ����
	std::ofstream SequenceFile;
	SequenceFile.open(Path, std::ios::out | std::ios::binary);
	if (!SequenceFile.is_open())
	{
		MessageBoxA(0, "Create File Failed", "Warning", MB_OK);
		return false;
	}

	int SequenceLength = target->Sequences[0]->mFrameLength;

	SequenceFile << SequenceLength;

	for (int submeshIDX = 0; submeshIDX < target->SubmeshCount; submeshIDX++)
	{
		for (int FrameIDX = 0; FrameIDX < SequenceLength; FrameIDX++)
		{
			for (int ClusterIDX = 0; ClusterIDX < target->BoneCount; ClusterIDX++)
			{
				for (int i = 0; i < 16; i++)
				{
					SequenceFile.write(
						reinterpret_cast<const char*>(&target->Sequences[0]->mAnimVertexArrays[submeshIDX][FrameIDX][ClusterIDX][i]),
						sizeof(float)
					);
				}
			}
		}
	}

	SequenceFile.close();

	return true;
}

bool ObjectData::ExportAnimationMontage()
{
	std::string DirPath =
		"MetaData\\" + this->objectName + "\\Montage";
	std::string Path;

	// ���� ����
	std::filesystem::path p(DirPath);
	if (!std::filesystem::is_directory(p))
		std::filesystem::create_directories(p);

	// ���� ���� �� ����
	std::ofstream MontageFile;

	Montage* montage = nullptr;
	

	for (std::pair<std::string, Montage> mont : Montages)
	{
		montage = &mont.second;

		Path = DirPath + "\\" + montage->mName + ".mont";

		// Load or Create File
		MontageFile.open(Path, std::ios::out | std::ios::binary);
		if (!MontageFile.is_open())
		{
			MessageBoxA(0, "Create Montage File Failed", "Warning", MB_OK);
			return false;
		}

		// Start to write
		UINT SequenceCount = montage->mSequenceList.size();

		// ��Ÿ���� ������ ������ ����
		MontageFile << SequenceCount;

		for (Montage::SequenceClip clip : montage->mSequenceList)
		{
			MontageFile.write(
				reinterpret_cast<const char*>(clip.mSequence->mName.c_str()), 
				clip.mSequence->mName.size()
			);
			MontageFile.write(
				reinterpret_cast<const char*>(clip.mClipStartFrame),
				sizeof(UINT)
			);
			MontageFile.write(
				reinterpret_cast<const char*>(clip.mClipEndFrame),
				sizeof(UINT)
			);
		}

		MontageFile.close();
	}

	return true;
}

bool ObjectData::ExportAnimationMorph(ObjectData* target, std::string name)
{
	// �޽� ����
	if (!CheckSibilingMesh(target))
		return false;

	std::string DirPath =
		"MetaData\\" + this->objectName + "\\Morph";
	std::string Path;

	if (name.empty())
	{
		Path = DirPath + "\\" + target->objectName + ".mph";
	}
	else
	{
		Path = DirPath + "\\" + name + ".mph";
	}

	// ���� ����
	std::filesystem::path p(DirPath);
	if (!std::filesystem::is_directory(p))
		std::filesystem::create_directories(p);

	// ���� ���� �� ����
	std::ofstream MorphFile;
	MorphFile.open(Path, std::ios::out | std::ios::binary);
	if (!MorphFile.is_open())
	{
		MessageBoxA(0, "Create File Failed", "Warning", MB_OK);
		return false;
	}

	for (int submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
	{
		MorphFile.write(
			reinterpret_cast<const char*>(target->meshDatas[submeshIDX].Vertices.size()),
			sizeof(UINT)
		);

		MorphFile.write(
			reinterpret_cast<const char*>(target->meshDatas[submeshIDX].Vertices.data()),
			target->meshDatas[submeshIDX].Vertices.size() * sizeof(Vertex)
		);
	}

	MorphFile.close();

	return true;
}
