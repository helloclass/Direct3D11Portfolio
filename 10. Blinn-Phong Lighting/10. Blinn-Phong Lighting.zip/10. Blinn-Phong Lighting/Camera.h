#pragma once
#include "Controller.h"

// Delta Time�� �̱��� �����
class Camera
{
private:
    float3 Position = { 0.0f, 0.0f, 0.0f };
    // Roll, Pitch, Yaw
    float3  EulerRotation = { 0.0f, 0.0f, 0.0f };

    float4x4 CameraViewMatrix = {
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f,
    };
    float4x4 InvCameraViewMatrix = {
    1.0f, 0.0f, 0.0f, 0.0f,
    0.0f, 1.0f, 0.0f, 0.0f,
    0.0f, 0.0f, 1.0f, 0.0f,
    0.0f, 0.0f, 0.0f, 1.0f,
    };

    float CameraMoveSpeed = 100.0f;
    float CameraTurnSpeed = M_PI * 30.0f;

    float DeltaTime = 0.0f;

private:
    bool IsMouseRClicked = false;

public:
    // ī�޶��� �⺻ ������ ���� 1
    /*
        View Matrix =
        {
            X_x, Y_x, Z_x, P_x,
            X_y, Y_y, Z_y, P_y,
            X_z, Y_z, Z_z, P_z,
            0  , 0  , 0  , 1
        }
    */
    inline float3 GetForwardVector()
    {
        float3 L = {
            CameraViewMatrix.m[0][2],
            CameraViewMatrix.m[1][2],
            CameraViewMatrix.m[2][2],
        };

        L = normalise(L);

        return L;
    }

    inline float3 GetUpVector()
    {
        float3 U = {
            CameraViewMatrix.m[0][1],
            CameraViewMatrix.m[1][1],
            CameraViewMatrix.m[2][1],
        };

        U = normalise(U);

        return U;
    }

    inline float3 GetRightVector()
    {
        float3 R = {
            CameraViewMatrix.m[0][0],
            CameraViewMatrix.m[1][0],
            CameraViewMatrix.m[2][0],
        };

        R = normalise(R);

        return R;
    }

    inline void MoveForward()
    {
        float3 L = {
            CameraViewMatrix.m[0][2],
            CameraViewMatrix.m[1][2],
            CameraViewMatrix.m[2][2],
        };

        L = normalise(L);

        Position.x -= L.x * CameraMoveSpeed * DeltaTime;
        Position.y -= L.y * CameraMoveSpeed * DeltaTime;
        Position.z -= L.z * CameraMoveSpeed * DeltaTime;
    }
    inline void MoveBackward()
    {
        float3 L = {
            CameraViewMatrix.m[0][2],
            CameraViewMatrix.m[1][2],
            CameraViewMatrix.m[2][2],
        };

        L = normalise(L);

        Position.x += L.x * CameraMoveSpeed * DeltaTime;
        Position.y += L.y * CameraMoveSpeed * DeltaTime;
        Position.z += L.z * CameraMoveSpeed * DeltaTime;
    }

    inline void MoveLeft()
    {
        float3 L = {
            CameraViewMatrix.m[0][0],
            CameraViewMatrix.m[1][0],
            CameraViewMatrix.m[2][0],
        };

        L = normalise(L);

        Position.x -= CameraViewMatrix.m[0][0] * CameraMoveSpeed * DeltaTime;
        Position.y -= CameraViewMatrix.m[1][0] * CameraMoveSpeed * DeltaTime;
        Position.z -= CameraViewMatrix.m[2][0] * CameraMoveSpeed * DeltaTime;
    }

    inline void MoveRight()
    {
        Position.x += CameraViewMatrix.m[0][0] * CameraMoveSpeed * DeltaTime;
        Position.y += CameraViewMatrix.m[1][0] * CameraMoveSpeed * DeltaTime;
        Position.z += CameraViewMatrix.m[2][0] * CameraMoveSpeed * DeltaTime;
    }

    inline void MoveUp()
    {
        Position.x += CameraViewMatrix.m[0][1] * CameraMoveSpeed * DeltaTime;
        Position.y += CameraViewMatrix.m[1][1] * CameraMoveSpeed * DeltaTime;
        Position.z += CameraViewMatrix.m[2][1] * CameraMoveSpeed * DeltaTime;
    }

    inline void MoveDown()
    {
        Position.x -= CameraViewMatrix.m[0][1] * CameraMoveSpeed * DeltaTime;
        Position.y -= CameraViewMatrix.m[1][1] * CameraMoveSpeed * DeltaTime;
        Position.z -= CameraViewMatrix.m[2][1] * CameraMoveSpeed * DeltaTime;
    }

    inline void Yaw(float delta)
    {
        float degree = delta * CameraTurnSpeed * DeltaTime;

        EulerRotation.y += degree;
        while (EulerRotation.y > 2.0f * M_PI)
            EulerRotation.y = 0.0f;

        CameraViewMatrix = CameraViewMatrix * rotateYMat(DirectX::XMConvertToRadians(degree));
        InvCameraViewMatrix = InvCameraViewMatrix * rotateYMat(DirectX::XMConvertToRadians(-degree));
    }

    inline void Roll(float delta)
    {
        float degree = delta * CameraTurnSpeed * DeltaTime;

        EulerRotation.z += degree;
        while (EulerRotation.z > 2.0f * M_PI)
            EulerRotation.z = 0.0f;

        CameraViewMatrix = CameraViewMatrix * rotateZMat(DirectX::XMConvertToRadians(degree));
        InvCameraViewMatrix = InvCameraViewMatrix * rotateZMat(DirectX::XMConvertToRadians(-degree));
    }

    inline void Pitch(float delta)
    {
        float degree = delta * CameraTurnSpeed * DeltaTime;

        EulerRotation.x += degree;
        while (EulerRotation.x > 2.0f * M_PI)
            EulerRotation.x = 0.0f;

        CameraViewMatrix = CameraViewMatrix * rotateXMat(DirectX::XMConvertToRadians(degree));
        InvCameraViewMatrix = InvCameraViewMatrix * rotateXMat(DirectX::XMConvertToRadians(-degree));
    }

    /*
        TranslationMat * RotationMat��
        RotationMat * TranslationMat���� ��ȯ�ϸ� Spring Arm�� ��.
    */

    // World To NDC
    inline float4x4 getViewMat()
    {
        return translationMat(-Position) * InvCameraViewMatrix;
    }

    // NDC To World
    inline float4x4 getInvViewMat()
    {
        return CameraViewMatrix * translationMat(Position);
    }

    void Update();
    void HandleUpdate();
};

class CameraPool {
private:
    static CameraPool gCameraPool;

    UINT mainCameraIDX;
    Camera cameras[10];

public:
    const UINT MaxCameraCount = 10;

public:
    static inline CameraPool& getInstance()
    {
        return gCameraPool;
    }

    Camera& getCamera()
    {
        return cameras[mainCameraIDX];
    }

    void setMainCamera(UINT camIndex)
    {
        if (camIndex < 10)
            mainCameraIDX = camIndex;
    }
};