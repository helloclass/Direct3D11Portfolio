#include "PhysicsObjectData.h"

#pragma region Transpose

StaticObjectData::StaticObjectData() {
	ObjectData::ObjectData();

	physicsType = PhysicsType::STATIC_TYPE;
}

void StaticObjectData::Awake() {
	ObjectData::Awake();

}

void StaticObjectData::Start() {
	ObjectData::Start();

	std::unordered_map<std::string, Instance>::iterator iter;
	std::unordered_map<std::string, Instance>::iterator end;
	iter = transform.instBuffer.begin();
	end = transform.instBuffer.end();

	PxShape* shape = nullptr;
	PxRigidStatic* body = nullptr;
	PxTransform position;

	// �ν��Ͻ� ��ŭ PhysicsBody ä���
	while (iter != end)
	{
		shape = PhysxPool::getInstance().physics.CreateBox(
			iter->second.Scale[0] * 0.5f,
			iter->second.Scale[1] * 0.5f,
			iter->second.Scale[2] * 0.5f
		);

		// �ٵ� �����
		body = PhysxPool::getInstance().physics.CreateStatic(
			PxTransform(PxVec3(0, 0, 0)),
			shape
		);
		// �ν��Ͻ� ��ġ�� ����
		position = PxTransform(
			iter->second.Position[0],
			iter->second.Position[1],
			iter->second.Position[2]
		);

		body->setGlobalPose(position);
		// PhysicsBody �߰�
		PhysicsBody[iter->first] = body;

		iter++;
	}
}

void StaticObjectData::Update() {
	ObjectData::Update();

}

void StaticObjectData::Destroy() {
	ObjectData::Destroy();
}

KinematicObjectData::KinematicObjectData() {
	ObjectData::ObjectData();

	physicsType = PhysicsType::KINEMATIC_TYPE;
}

void KinematicObjectData::Awake() {
	ObjectData::Awake();

}

void KinematicObjectData::Start()
{
	ObjectData::Start();

	std::unordered_map<std::string, Instance>::iterator iter;
	std::unordered_map<std::string, Instance>::iterator end;
	iter = transform.instBuffer.begin();
	end = transform.instBuffer.end();

	PxRigidDynamic* body = nullptr;
	PxShape* shape = nullptr;
	PxTransform position;
	float density = 0.1f;
	PxVec3 velocity = {};

	while (iter != end)
	{
		shape = PhysxPool::getInstance().physics.CreateBox(
			iter->second.Scale[0] * 0.5f,
			iter->second.Scale[1] * 0.5f,
			iter->second.Scale[2] * 0.5f
		);

		body = PhysxPool::getInstance().physics.CreateKinematic(
			PxTransform(PxVec3(0, 0, 0)),
			shape,
			density,
			velocity
		);

		position = PxTransform(
			iter->second.Position[0],
			iter->second.Position[1],
			iter->second.Position[2]
		);

		body->setGlobalPose(position);

		PhysicsBody[iter->first] = body;

		iter++;
	}
}

void KinematicObjectData::Update() 
{
	ObjectData::Update();

	// if Play Button Clicked
	{
		std::unordered_map<std::string, Instance>::iterator iter;
		std::unordered_map<std::string, Instance>::iterator end;
		iter = transform.instBuffer.begin();
		end = transform.instBuffer.end();

		PxVec3 position = {};

		while (iter != end)
		{
			position = PhysicsBody[iter->first]->getGlobalPose().p;

			iter->second.Position[0] = position.x;
			iter->second.Position[1] = position.y;
			iter->second.Position[2] = position.z;

			iter++;
		}
	}
}

void KinematicObjectData::Destroy() {
	ObjectData::Destroy();
}

DynamicObjectData::DynamicObjectData()
{
	ObjectData::ObjectData();

	physicsType = PhysicsType::DYNAMIC_TYPE;

}

void DynamicObjectData::Awake() {
	ObjectData::Awake();

}

void DynamicObjectData::Start()
{
	std::unordered_map<std::string, Instance>::iterator iter;
	std::unordered_map<std::string, Instance>::iterator end;
	iter = transform.instBuffer.begin();
	end = transform.instBuffer.end();

	PxRigidDynamic* body = nullptr;
	PxShape* shape = nullptr;
	PxTransform position;
	float density = 0.1f;
	PxVec3 velocity = {};

	while (iter != end)
	{
		shape = PhysxPool::getInstance().physics.CreateBox(
			iter->second.Scale[0] * 0.5f,
			iter->second.Scale[1] * 0.5f,
			iter->second.Scale[2] * 0.5f
		);

		body = PhysxPool::getInstance().physics.CreateDynamic(
			PxTransform(PxVec3(0, 0, 0)),
			shape->getGeometry().any(),
			velocity
		);

		position = PxTransform(
			iter->second.Position[0],
			iter->second.Position[1],
			iter->second.Position[2]
		);

		body->setGlobalPose(position);

		PhysicsBody[iter->first] = body;

		iter++;
	}
}

void DynamicObjectData::Update() 
{
	ObjectData::Update();

	/*
		�ִϸ��̼� ���� ��� ��Ÿ�� ������Ʈ ��Ŵ.

		��Ÿ�� ���� �ִϸ��̼ǿ� ���� ���� ��Ʈ������ �߰������� �ԷµǴ� ����ġ��
		���� �������� ���� �� �������� ������ִ� ����ġ ������ ��.

		O(n) ���⵵�� ����� ũ�� ������� ����.
	*/
	UpdateBoneDelta();

	// if Play Button Clicked
	{
		std::unordered_map<std::string, Instance>::iterator iter;
		std::unordered_map<std::string, Instance>::iterator end;
		iter = transform.instBuffer.begin();
		end = transform.instBuffer.end();

		PxVec3 position = {};

		while (iter != end)
		{
			position = PhysicsBody[iter->first]->getGlobalPose().p;

			iter->second.Position[0] = position.x;
			iter->second.Position[1] = position.y;
			iter->second.Position[2] = position.z;

			iter++;
		}
	}
}

void DynamicObjectData::Destroy() {
	ObjectData::Destroy();
}

Instance DynamicObjectData::getParentInstance()
{
	Instance ParentInstance = {};

	Tree<ObjectData*>* Root = &Childs;
	
	while (Root->Parent)
	{
		Root = Root->Parent;

		ParentInstance.Position[0] += Root->Item->transform.instBuffer[0].Position[0];
		ParentInstance.Position[1] += Root->Item->transform.instBuffer[0].Position[1];
		ParentInstance.Position[2] += Root->Item->transform.instBuffer[0].Position[2];

		ParentInstance.Rotation[0] += Root->Item->transform.instBuffer[0].Rotation[0];
		ParentInstance.Rotation[1] += Root->Item->transform.instBuffer[0].Rotation[1];
		ParentInstance.Rotation[2] += Root->Item->transform.instBuffer[0].Rotation[2];

		ParentInstance.Scale[0] += Root->Item->transform.instBuffer[0].Scale[0];
		ParentInstance.Scale[1] += Root->Item->transform.instBuffer[0].Scale[1];
		ParentInstance.Scale[2] += Root->Item->transform.instBuffer[0].Scale[2];
	}

	return ParentInstance;
}

// Max InstanceCount is 2000 
void StaticObjectData::Instantiate()
{
	std::string instName = transform.Name + "_" + std::to_string(transform.ID_Count);

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			transform.instBuffer.size() * 25.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f
	};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidStatic* body = PhysxPool::getInstance().physics.CreateStatic(
		PxTransform(PxVec3(0, 0, 0)),
		shape
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

// Max InstanceCount is 2000 
void StaticObjectData::Instantiate (std::string instName)
{
	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			transform.instBuffer.size() * 25.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f
	};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidStatic* body = PhysxPool::getInstance().physics.CreateStatic(
		PxTransform(PxVec3(0, 0, 0)),
		shape
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void StaticObjectData::Instantiate(Instance& t)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			t.Position[0],	t.Position[1],	t.Position[2],
			t.Rotation[0],	t.Rotation[1],	t.Rotation[2],
			t.Scale[0],		t.Scale[0],		t.Scale[0],
	};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidStatic* body = PhysxPool::getInstance().physics.CreateStatic(
		PxTransform(PxVec3(0)),
		shape
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void StaticObjectData::Instantiate(float3 Position)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = 
		{
			Position.x, Position.y, Position.z,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f,
		};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidStatic* body = PhysxPool::getInstance().physics.CreateStatic(
		PxTransform(PxVec3(0)),
		shape
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void StaticObjectData::Destroy(std::string name)
{
	for (std::pair<std::string, Instance> t : transform.instBuffer)
	{
		if (!strcmp(t.first.c_str(), name.c_str()))
		{
			// World List ���� �����ϱ�
			transform.instBuffer.erase(t.first);
			// Physx Body �����ϱ�
			PhysicsBody.erase(t.first.c_str());

			transform.InstanceCount--;
			transform.InstanceDirty = true;

			break;
		}
	}
}

// Max InstanceCount is 2000 
void KinematicObjectData::Instantiate()
{
	std::string instName = transform.Name + "_" + std::to_string(transform.ID_Count);

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			transform.instBuffer.size() * 25.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f
	};

	float density = 0.1f;
	PxVec3 velocity = {};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateKinematic(
		PxTransform(PxVec3(0)),
		shape,
		density,
		velocity
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void KinematicObjectData::Instantiate(Instance& t)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			t.Position[0],	t.Position[1],	t.Position[2],
			t.Rotation[0],	t.Rotation[1],	t.Rotation[2],
			t.Scale[0],		t.Scale[0],		t.Scale[0],
	};

	float density = 0.1f;
	PxVec3 velocity = {};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateKinematic(
		PxTransform(PxVec3(0)),
		shape,
		density,
		velocity
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void KinematicObjectData::Instantiate(float3 Position)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] =
		{
			Position.x, Position.y, Position.z,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f,
		};

	float density = 0.1f;
	PxVec3 velocity = {};

	// �ٵ� �����
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateKinematic(
		PxTransform(PxVec3(0)),
		shape,
		density,
		velocity
	);
	// �ν��Ͻ� ��ġ�� ����
	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);

	body->setGlobalPose(position);
	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void KinematicObjectData::Destroy(std::string name)
{
	for (std::pair<std::string, Instance> t : transform.instBuffer)
	{
		if (!strcmp(t.first.c_str(), name.c_str()))
		{
			// World List ���� �����ϱ�
			transform.instBuffer.erase(t.first);
			// Physx Body �����ϱ�
			PhysicsBody.erase(t.first.c_str());

			transform.InstanceCount--;
			transform.InstanceDirty = true;

			break;
		}
	}
}


// Max InstanceCount is 2000 
void DynamicObjectData::Instantiate()
{
	std::string instName = transform.Name + "_" + std::to_string(transform.ID_Count);

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			transform.instBuffer.size() * 25.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f
	};

	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);
	PxShape* shape = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	);
	PxVec3 velocity = PxVec3(0.0f);

	// �ٵ� �����
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateDynamic(
		PxTransform(PxVec3(0, 0, 0)),
		shape->getGeometry().any(),
		velocity
	);

	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void DynamicObjectData::Instantiate(Instance& t)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] = {
			t.Position[0],	t.Position[1],	t.Position[2],
			t.Rotation[0],	t.Rotation[1],	t.Rotation[2],
			t.Scale[0],		t.Scale[0],		t.Scale[0],
	};

	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);
	PxGeometry geom = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	)->getGeometry().any();
	PxVec3 velocity = PxVec3(0.0f);

	// �ٵ� �����
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateDynamic(
		position,
		geom,
		velocity
	);

	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void DynamicObjectData::Instantiate(float3 Position)
{
	std::string instName = transform.Name + "(" + std::to_string(transform.ID_Count) + ")";

	UI_ListBox* listbox = &HWNDPool::getInstance().WorldListBox;
	listbox->AppendListBoxMessage(instName);

	transform.instBuffer[instName] =
		{
			Position.x, Position.y, Position.z,
			0.0f, 0.0f, 0.0f,
			1.0f, 1.0f, 1.0f,
		};

	PxTransform position = PxTransform(
		transform.instBuffer[instName].Position[0],
		transform.instBuffer[instName].Position[1],
		transform.instBuffer[instName].Position[2]
	);
	PxGeometry geom = PhysxPool::getInstance().physics.CreateBox(
		transform.instBuffer[instName].Scale[0] * 0.5f,
		transform.instBuffer[instName].Scale[1] * 0.5f,
		transform.instBuffer[instName].Scale[2] * 0.5f
	)->getGeometry().any();
	PxVec3 velocity = PxVec3(0.0f);

	// �ٵ� �����
	PxRigidDynamic* body = PhysxPool::getInstance().physics.CreateDynamic(
		position,
		geom,
		velocity
	);

	// PhysicsBody �߰�
	PhysicsBody[instName] = body;

	transform.ID_Count++;
	transform.InstanceCount++;
	transform.InstanceDirty = true;
}

void DynamicObjectData::Destroy(std::string name)
{
	for (std::pair<std::string, Instance> t : transform.instBuffer)
	{
		if (!strcmp(t.first.c_str(), name.c_str()))
		{
			// World List ���� �����ϱ�
			transform.instBuffer.erase(t.first);
			// Physx Body �����ϱ�
			PhysicsBody.erase(t.first.c_str());
			
			transform.InstanceCount--;
			transform.InstanceDirty = true;

			break;
		}
	}
}

void DynamicObjectData::GetAllBones(std::unordered_map<std::string, float4x4>& Bones)
{
	UINT submeshIDX = 0;
	UINT clusterIndex = 0;

	int currentFrame = 0;

	FbxSkin* lSkinDeformer;

	UINT lClusterCount = 0;
	FbxCluster* lCluster;

	std::string name;
	float4x4 translate;
	int i(0), j(0), k(0);

	fbxsdk::FbxVector4* vertices;
	fbxsdk::FbxVector4 result;

	fbxsdk::FbxAMatrix matrix;

	int* mIndices = nullptr;



	// �ִϸ��̼��� ������Ʈ �Ѵ�.
	if (objType == ObjectType::FBX_SKINNED_TYPE)
	{
		if (CurrentAsset->mType == AnimationAsset::AnimationAssetType::SEQUENCE)
		{
			/*Sequence* asset = (Sequence*)GetAsset();*/
			Sequence* asset = reinterpret_cast<Sequence*>(GetAsset());

			currentFrame = asset->mFrame;

			for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
			{
				vertices = meshFBXDatas[submeshIDX]->GetControlPoints();

				lSkinDeformer =
					(FbxSkin*)meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

				lClusterCount =
					lSkinDeformer->GetClusterCount();

				for (clusterIndex = 0; clusterIndex < lClusterCount; clusterIndex++)
				{
					lCluster = lSkinDeformer->GetCluster(clusterIndex);
					mIndices = lCluster->GetControlPointIndices();

					if (!mIndices)
						continue;

					name = lCluster->GetNameOnly();

					asset->GetAnimationMatrix(submeshIDX, clusterIndex, translate);

					result = matrix.MultT(vertices[mIndices[0]]);

					Bones[name] = translate;

				} // ClusterCount
			} // SubmeshCount
		}
		else if (CurrentAsset->mType == AnimationAsset::AnimationAssetType::MONTAGE)
		{
			Montage* asset = (Montage*)GetAsset();

			currentFrame = asset->mFrame;

			for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
			{
				vertices = meshFBXDatas[submeshIDX]->GetControlPoints();

				lSkinDeformer =
					(FbxSkin*)meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

				lClusterCount =
					lSkinDeformer->GetClusterCount();

				for (clusterIndex = 0; clusterIndex < lClusterCount; clusterIndex++)
				{
					lCluster = lSkinDeformer->GetCluster(clusterIndex);
					mIndices = lCluster->GetControlPointIndices();

					if (!mIndices)
						continue;

					name = lCluster->GetNameOnly();

					asset->GetAnimationMatrix(submeshIDX, clusterIndex, translate);

					result = matrix.MultT(vertices[mIndices[0]]);

					Bones[name] = translate;

				} // ClusterCount
			} // SubmeshCount
		}
		else
		{
			BlendSpace* asset = (BlendSpace*)GetAsset();

			currentFrame = asset->mFrame;

			for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
			{
				vertices = meshFBXDatas[submeshIDX]->GetControlPoints();

				lSkinDeformer =
					(FbxSkin*)meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

				lClusterCount =
					lSkinDeformer->GetClusterCount();

				for (clusterIndex = 0; clusterIndex < lClusterCount; clusterIndex++)
				{
					lCluster = lSkinDeformer->GetCluster(clusterIndex);
					mIndices = lCluster->GetControlPointIndices();

					if (!mIndices)
						continue;

					name = lCluster->GetNameOnly();

					asset->GetAnimationMatrix(submeshIDX, clusterIndex, translate);

					result = matrix.MultT(vertices[mIndices[0]]);

					Bones[name] = translate;

				} // ClusterCount
			} // SubmeshCount
		}
	}

}

void DynamicObjectData::GetAllSockets(std::unordered_map<std::string, float4x4>& Socket)
{

}

#pragma endregion
