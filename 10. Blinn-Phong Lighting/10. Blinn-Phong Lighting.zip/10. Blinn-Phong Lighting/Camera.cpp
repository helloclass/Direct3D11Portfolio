#include "Camera.h"

CameraPool CameraPool::gCameraPool;

void Camera::Update()
{
    DeltaTime = GlobalTime::getInstance().dt;

    // Calc Delta Mouse Point
    HandleUpdate();

    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionMoveCamFwd])
        MoveForward();
    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionMoveCamBack])
        MoveBackward();
    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionMoveCamLeft])
        MoveLeft();
    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionMoveCamRight])
        MoveRight();
    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionRaiseCam])
        MoveUp();
    if (GlobalKeyVector::getInstance().global_KeyboardBehavior[GameActionLowerCam])
        MoveDown();

    if (IsMouseRClicked)
    {
        Yaw(-Controller::getInstance().DeltaPoint.x);
        Pitch(-Controller::getInstance().DeltaPoint.y);
    }
}

void Camera::HandleUpdate()
{
     if (GlobalKeyVector::getInstance().global_MouseBehavior[MouseActionRightDown])
    {
         GlobalKeyVector::getInstance().global_MouseBehavior[MouseActionRightDown] = false;
        IsMouseRClicked = true;
    }
    if (GlobalKeyVector::getInstance().global_MouseBehavior[MouseActionRightUp])
    {
        GlobalKeyVector::getInstance().global_MouseBehavior[MouseActionRightUp] = false;
        IsMouseRClicked = false;
    }
}