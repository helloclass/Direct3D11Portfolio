#pragma once

#pragma warning(disable:4996)

#include <iostream>

#ifndef PHYSX_SAMPLE_H

#define PHYSX_SAMPLE_H

#include "PxPhysicsAPI.h"
#include <extensions/PxExtensionsAPI.h>
#include <extensions/PxDefaultErrorCallback.h>

#endif

using namespace physx;

class Physics {
private:
	PxDefaultErrorCallback gErrorCallback;
	PxDefaultAllocator gAllocator;

	PxFoundation* gFoundation;
	PxPvd* gPvd;
	PxPhysics* gPhysics;
	PxCooking* gCooking;

	PxDefaultCpuDispatcher* gDispatcher;

	PxScene* gScene;

	PxMaterial* gMaterial;

public:
	void Init();
	void Update();
	void CleanUp();

	PxRigidStatic* CreateStatic(const PxTransform& t, PxShape* shape);
	PxRigidDynamic* CreateKinematic(const PxTransform& t, PxShape* shape, float density, const PxVec3& velocity);
	PxRigidDynamic* CreateDynamic(const PxTransform& t, const PxGeometry& geometry, const PxVec3& velocity);

	PxShape* CreateBox(float x, float y, float z);
	PxShape* CreateSphere(float r);
	PxConvexMesh* CreateConvexMesh(const PxConvexMeshDesc& convexDesc);
	PxTriangleMesh* CreateTriangleMesh(const PxTriangleMeshDesc& meshDesc);
	PxShape* CreateCapsule(float r);
	void CreateStack(PxShape* shape, const PxTransform& t, PxU32 size, PxReal halfExtent);
	PxShape* CreateConvexMeshToShape(const PxConvexMeshDesc& convexDesc);
	PxShape* CreateTriangleMeshToShape(const PxTriangleMeshDesc& meshDesc);

	void setPosition(PxRigidDynamic* collider, float x, float y, float z);
	void setRotation(PxRigidDynamic* collider, float x, float y, float z);
	void setVelocity(PxRigidDynamic* collider, float x, float y, float z);
	void setTorque(PxRigidDynamic* collider, float x, float y, float z);

};

class PhysxPool {
private:
	static PhysxPool pool;

public:
	static PhysxPool& getInstance() {
		return pool;
	}

public:
	Physics physics;
};