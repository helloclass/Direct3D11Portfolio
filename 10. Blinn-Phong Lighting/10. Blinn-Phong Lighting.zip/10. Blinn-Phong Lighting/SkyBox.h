#pragma once
#include "DirectX.h"

class SkyBox : public StaticObjectData
{
private:
	std::string ObjectName = "Skybox";
	std::string ObjectPath = "Resource\\skybox.fbx";

public:
	SkyBox() {
		StaticObjectData::StaticObjectData();

		fbxLoader.CreateFBXModel(
			this,
			ObjectName,
			ObjectPath
		);

		ShaderID = "SkyBox.hlsl";
	}

	void Awake() {
		StaticObjectData::Awake();

	}

	void Start() {
		StaticObjectData::Start();

	}

	void Update() {
		StaticObjectData::Update();

	}

	void Destroy() {
		StaticObjectData::Destroy();

	}
};