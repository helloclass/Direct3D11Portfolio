#pragma once
#include "DirectX.h"

class Axis : public StaticObjectData
{
private:
	std::string ObjectName = "Axis";
	std::string ObjectPath = "Resource\\axis.fbx";

public:
	Axis() {
		StaticObjectData::StaticObjectData();

		fbxLoader.CreateFBXModel(
			this,
			ObjectName,
			ObjectPath
		);

		ShaderID = "Axis.hlsl";
		bIsEnableDepthStencil = false;
	}

	void Awake() {
		StaticObjectData::Awake();
	}

	void Start() {
		StaticObjectData::Start();

	}

	void Update() {
		StaticObjectData::Update();

	}

	void Destroy() {
		StaticObjectData::Destroy();

	}
};