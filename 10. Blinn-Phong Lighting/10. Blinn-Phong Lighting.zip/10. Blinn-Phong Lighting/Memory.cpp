#include "Memory.h"

HWNDPool HWNDPool::pool;
MemoryPool MemoryPool::pool;