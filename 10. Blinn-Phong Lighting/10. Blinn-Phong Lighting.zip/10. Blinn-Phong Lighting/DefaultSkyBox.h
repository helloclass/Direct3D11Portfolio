#pragma once
#include "DirectX.h"

class DefaultSkyBox : public StaticObjectData
{
private:
	std::string ObjectName = "DefaultSkybox";
	std::string ObjectPath = "Resource\\defaultSkybox.FBX";

public:
	DefaultSkyBox() {
		StaticObjectData::StaticObjectData();

		fbxLoader.CreateFBXModel(
			this,
			ObjectName,
			ObjectPath
		);

		ShaderID = "SkyBox.hlsl";
	}

	void Awake() {
		StaticObjectData::Awake();
	}

	void Start() {
		StaticObjectData::Start();

	}

	void Update() {
		StaticObjectData::Update();

	}

	void Destroy() {
		StaticObjectData::Destroy();

	}
};

