#pragma once

#ifndef KFBX_DLLINFO
#define KFBX_DLLINFO
#endif // !KFBX_DLLINFO

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif // !WIN32_LEAN_AND_MEAN

#ifndef NOMINMAX
#define NOMINMAX
#endif // !NOMINMAX

#ifndef UNICODE
#define UNICODE
#endif // !UNICODE

#include "CreateWindows.h"
#include "ObjLoading.h"

class DirectXHelper {
private:
	const HWND* MainHWND;

	// SwapChain
	IDXGISwapChain1* d3d11SwapChain;
	ID3D11RenderTargetView* renderBufferView;

	// Diferred RTV
	ID3D11Texture2D* m_renderTargetTexture;
	ID3D11RenderTargetView* deferRenderTargetView;
	ID3D11ShaderResourceView* m_shaderResourceView;

	// Diferred DSV
	ID3D11Texture2D* depthBuffer;
	ID3D11DepthStencilView* depthBufferView;
	ID3D11DepthStencilView* deferDepthBufferView;
	ID3D11ShaderResourceView* depthResourceView;

	// Create Vertex, Pixel Shader for BoundBox 
	ID3DBlob* BoundBoxVsCode;
	ID3D11VertexShader* BoundBoxVertexShader;
	ID3D11PixelShader* BoundBoxPixelShader;

	float4x4 perspectiveMat = {};

public:
	DirectXHelper();
	~DirectXHelper();

	DWORD Init(const HWND& mHWND);
	DWORD Update();
	DWORD Destroy();

public:
	DWORD MaterialUpdate(ObjectData* objIter, UINT submeshIDX);

private:
	DWORD CreateDeviceAndContext();
	//  DirectX Graphics Infrastructor support a service about Monitor Information or Controller.
	DWORD CreateDXGI();
	DWORD CreateSwapChain();
	DWORD CreateRenderDepthTargets();

	DWORD CreateShaders();
	DWORD CreateShadowShader();
	DWORD CreateInputDescriptor();

	DWORD CreateSampler();

	DWORD LoadObject();
	DWORD LoadTexture();

	DWORD CreateLightCBV();
	DWORD CreateVertexShaderConstantBuffer();
	DWORD CreatePixelShaderConstantBuffer();

	DWORD CreateRasterizerState();
	DWORD CreateDepthStencilState();

	DWORD CreateQuary();
};

static DirectXHelper _DirectXHelper;

static DWORD hAnimThreadID;
static DWORD hAnimThreadParam = 0;
static HANDLE hAnimThread;

static HANDLE hAnimThreadReadEvent;
static HANDLE hAnimThreadWriteEvent;

static fbx::FBXLoader fbxLoader;