#pragma once
#include "DirectX.h"

class Bone : public StaticObjectData
{
private:
	std::string ObjectName = "Bone";
	std::string ObjectPath = "Resource\\Skeletal_Mesh.fbx";

	std::string TargetInstanceName;
	DynamicObjectData* Target = nullptr;

	std::unordered_map<std::string, float4x4> Bones;
	std::vector<int> Indices;
	UINT BoneSize;

public:
	Bone() {
		fbxLoader.CreateFBXModel(
			this,
			ObjectName,
			ObjectPath
		);

		ShaderID = "Axis.hlsl";
		bIsEnableDepthStencil = false;
	}

	void SetTarget(DynamicObjectData& data, std::string InstanceName)
	{
		Target = &data;
		TargetInstanceName = InstanceName;

		Target->GetAllBones(Bones);
		BoneSize = Bones.size();

		for (std::pair<std::string, float4x4> bone : Bones)
		{
			Instantiate(bone.first);
		}
	}

	DynamicObjectData* GetTarget()
	{
		return Target;
	}

	void Awake() {
		StaticObjectData::Awake();
	}

	void Start() {
		StaticObjectData::Start();

	}

	void Update() {
		StaticObjectData::Update();
		Instance* inst = nullptr;
		Instance* destInst = nullptr;
		float4x4 WorldMat;

		{
			UINT submeshIDX = 0;
			UINT currentFrame = 0;

			FbxSkin* lSkinDeformer;

			UINT lClusterCount = 0;
			UINT lClusterIndex = 0;
			FbxCluster* lCluster;

			std::string name;
			int i(0), j(0), k(0);

			fbxsdk::FbxVector4* vertices;
			fbxsdk::FbxVector4 result;

			fbxsdk::FbxAMatrix matrix;

			int* mIndices = nullptr;

			Tree<Skeleton>* bone = nullptr;

			float**** AnimVertexArray = nullptr;

			if (Target->CurrentAsset->mType == AnimationAsset::AnimationAssetType::SEQUENCE)
			{
				Sequence* asset = (Sequence*)Target->GetAsset();

				// �ִϸ��̼��� ������Ʈ �Ѵ�.
				currentFrame = asset->mFrame;

				for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
				{
					vertices = Target->meshFBXDatas[submeshIDX]->GetControlPoints();

					lSkinDeformer =
						(FbxSkin*)Target->meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

					lClusterCount =
						lSkinDeformer->GetClusterCount();

					for (lClusterIndex = 0; lClusterIndex < lClusterCount; lClusterIndex++)
					{
						lCluster = lSkinDeformer->GetCluster(lClusterIndex);
						mIndices = lCluster->GetControlPointIndices();

						if (!mIndices)
							continue;

						name = lCluster->GetNameOnly();

						bone = Target->BoneHierarchy.Find(name);

						asset->GetAnimationMatrix(submeshIDX, lClusterIndex, bone->Item.TranslationMatrix);
						asset->GetAnimationFBXMatrix(submeshIDX, lClusterIndex, matrix);

						result = matrix.MultT(vertices[mIndices[0]]);

						bone->Item.Position.x = result.mData[0];
						bone->Item.Position.y = result.mData[1];
						bone->Item.Position.z = result.mData[2];
						bone->Item.Position.w = result.mData[3];

					} // ClusterCount
				} // SubmeshCount
			}
			if (Target->CurrentAsset->mType == AnimationAsset::AnimationAssetType::MONTAGE)
			{
				Montage* asset = (Montage*)Target->GetAsset();

				// �ִϸ��̼��� ������Ʈ �Ѵ�.
				currentFrame = asset->mFrame;

				for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
				{
					vertices = Target->meshFBXDatas[submeshIDX]->GetControlPoints();

					lSkinDeformer =
						(FbxSkin*)Target->meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

					lClusterCount =
						lSkinDeformer->GetClusterCount();

					for (lClusterIndex = 0; lClusterIndex < lClusterCount; lClusterIndex++)
					{
						lCluster = lSkinDeformer->GetCluster(lClusterIndex);
						mIndices = lCluster->GetControlPointIndices();

						if (!mIndices)
							continue;

						name = lCluster->GetNameOnly();

						bone = Target->BoneHierarchy.Find(name);

						asset->GetAnimationMatrix(submeshIDX, lClusterIndex, bone->Item.TranslationMatrix);
						asset->GetAnimationFBXMatrix(submeshIDX, lClusterIndex, matrix);

						result = matrix.MultT(vertices[mIndices[0]]);

						bone->Item.Position.x = result.mData[0];
						bone->Item.Position.y = result.mData[1];
						bone->Item.Position.z = result.mData[2];
						bone->Item.Position.w = result.mData[3];

					} // ClusterCount
				} // SubmeshCount
			}
			if (Target->CurrentAsset->mType == AnimationAsset::AnimationAssetType::BLENDSPACE)
			{
				BlendSpace* asset = (BlendSpace*)Target->GetAsset();

				// �ִϸ��̼��� ������Ʈ �Ѵ�.
				currentFrame = asset->mFrame;

				for (submeshIDX = 0; submeshIDX < SubmeshCount; submeshIDX++)
				{
					vertices = Target->meshFBXDatas[submeshIDX]->GetControlPoints();

					lSkinDeformer =
						(FbxSkin*)Target->meshFBXDatas[submeshIDX]->GetDeformer(0, FbxDeformer::eSkin);

					lClusterCount =
						lSkinDeformer->GetClusterCount();

					for (lClusterIndex = 0; lClusterIndex < lClusterCount; lClusterIndex++)
					{
						lCluster = lSkinDeformer->GetCluster(lClusterIndex);
						mIndices = lCluster->GetControlPointIndices();

						if (!mIndices)
							continue;

						name = lCluster->GetNameOnly();

						bone = Target->BoneHierarchy.Find(name);

						asset->GetAnimationMatrix(submeshIDX, lClusterIndex, bone->Item.TranslationMatrix);
						asset->GetAnimationFBXMatrix(submeshIDX, lClusterIndex, matrix);

						result = matrix.MultT(vertices[mIndices[0]]);

						bone->Item.Position.x = result.mData[0];
						bone->Item.Position.y = result.mData[1];
						bone->Item.Position.z = result.mData[2];
						bone->Item.Position.w = result.mData[3];

					} // ClusterCount
				} // SubmeshCount
			}
		}

		if (Target)
		{
			float4 delta;
			std::vector<Tree<Skeleton>*> TargetBone;
			Target->BoneHierarchy.GetAllChilds(
				(Tree<Skeleton>*)Target->BoneHierarchy.Root, 
				TargetBone
			);

			for (Tree<Skeleton>* bone : TargetBone)
			{
				inst = &Target->transform.instBuffer[TargetInstanceName];
				destInst = &transform.instBuffer[bone->Name];

				if (!inst || !destInst)
					std::runtime_error("Bone not Found");

				destInst->Position[0]	= bone->Item.Position.x;
				destInst->Position[1]	= bone->Item.Position.y;
				destInst->Position[2]	= bone->Item.Position.z;

				destInst->Rotation[0]	= 0.0f;
				destInst->Rotation[1]	= 0.0f;
				destInst->Rotation[2]	= 0.0f;

				destInst->Scale[0]		= 1.0f;
				destInst->Scale[1]		= 1.0f;
				destInst->Scale[2]		= 1.0f;

				// Parent Bone���� Bone�� �ø�
				if (bone->Parent)
				{
					delta = bone->Parent->Item.Position - bone->Item.Position;

					Target->collider.Extents.x = delta.x;
					Target->collider.Extents.y = delta.y;
					Target->collider.Extents.z = delta.z;
				}
			}
		}
	}

	void Destroy() {
		StaticObjectData::Destroy();

	}
};